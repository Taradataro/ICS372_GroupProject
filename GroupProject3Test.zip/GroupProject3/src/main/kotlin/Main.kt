package org.example.hellofx
import javafx.application.Application

fun main() {
    Application.launch(DealerApplication::class.java)
}