
package com.trackingcompany.main;

/**
 *
 * @author ahlam
 */
public class SUV extends Vehicle {
    //Represents an SUV. This class extends the Vehicle class and inherits its properties
    public SUV(String vehicleId, String manufacture, String model, String acquisitionDate, double price) {
        super(vehicleId, manufacture, model, acquisitionDate, price);
    }
}
