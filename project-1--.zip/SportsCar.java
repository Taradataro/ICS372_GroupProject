package com.trackingcompany.main;

/**
 *
 * @author ahlam
 */
public class SportsCar extends Vehicle{
    //Represents a Sports Car. This class extends the Vehicle class and inherits its properties
    public SportsCar(String vehicleId, String manufacture, String model, String acquisitionDate, double price) {
        super(vehicleId, manufacture, model, acquisitionDate, price);
    }
}